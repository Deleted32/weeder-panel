Thanks for purchasing Silkystick

I'd recommend joining my discord support server for faster support.
In case you can't here are the files which you need to edit in order to change it!

For Silkystick
-> header.tpl - you can edit the vars with your mc server details and discord too.
-> navbar.tpl - look for eternity-element logo and edit the img src=
-> footer.tpl - look for <div class="right"> and edit the <a href=""> with your social media.
-> css/silkystick.css - on :root you can edit --main-color into your community color & --header-url into your background.

# 7088T4QKQRXA85